package com.example.autowallpaper;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.WallpaperManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;

import java.io.InputStream;

public class WallpaperAlarmReceiver extends BroadcastReceiver {
    private static final long DAY = 24L * 60L * 60L * 1000L;

    @Override public void onReceive(Context context, Intent intent) {
        SharedPreferences prefs = context.getSharedPreferences("wallpaper_prefs", Context.MODE_PRIVATE);
        if (!prefs.getBoolean("enabled", false)) return;
        String raw = prefs.getString("uris", "");
        if (raw == null || raw.trim().isEmpty()) return;
        String[] uris = raw.split("\\n");
        int index = prefs.getInt("next", 0);
        try (InputStream in = context.getContentResolver().openInputStream(Uri.parse(uris[index % uris.length]))) {
            Bitmap bitmap = BitmapFactory.decodeStream(in);
            if (bitmap != null) {
                WallpaperManager wm = WallpaperManager.getInstance(context);
                if (Build.VERSION.SDK_INT >= 24) {
                    wm.setBitmap(bitmap, null, true, WallpaperManager.FLAG_SYSTEM | WallpaperManager.FLAG_LOCK);
                } else {
                    wm.setBitmap(bitmap);
                }
                prefs.edit().putInt("next", (index + 1) % uris.length).apply();
            }
        } catch (Exception ignored) {
            // A photo may have been moved or its permission revoked; next scheduled run retries.
        }
        Intent next = new Intent(context, WallpaperAlarmReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(context, 42, next,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        long when = System.currentTimeMillis() + DAY;
        if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        else am.set(AlarmManager.RTC_WAKEUP, when, pi);
    }
}
