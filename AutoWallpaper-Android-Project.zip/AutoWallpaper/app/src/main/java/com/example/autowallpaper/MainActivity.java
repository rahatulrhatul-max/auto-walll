package com.example.autowallpaper;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.WallpaperManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {
    private static final int PICK_IMAGES = 101;
    private static final String PREFS = "wallpaper_prefs";
    private static final String KEY_URIS = "uris";
    private static final String KEY_NEXT = "next";
    private SharedPreferences prefs;
    private TextView status;
    private final List<String> selected = new ArrayList<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        loadUris();
        buildUi();
        updateStatus();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(22));
        root.setBackgroundColor(0xFFF4F6FA);

        TextView title = new TextView(this);
        title.setText("Auto Wallpaper");
        title.setTextSize(28);
        title.setTextColor(0xFF17356F);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1);
        root.addView(title, matchWrap());

        TextView desc = new TextView(this);
        desc.setText("Choose photos and let the app change your wallpaper every 24 hours.");
        desc.setTextSize(16);
        desc.setTextColor(0xFF333B49);
        desc.setGravity(Gravity.CENTER);
        desc.setPadding(0, dp(12), 0, dp(22));
        root.addView(desc, matchWrap());

        Button choose = button("Choose photos from gallery");
        choose.setOnClickListener(v -> pickImages());
        root.addView(choose, matchWrap());

        Button apply = button("Apply next wallpaper now");
        apply.setOnClickListener(v -> applyNext());
        LinearLayout.LayoutParams ap = matchWrap();
        ap.topMargin = dp(10);
        root.addView(apply, ap);

        Button start = button("Start daily automatic changes");
        start.setOnClickListener(v -> {
            if (selected.isEmpty()) {
                toast("Choose at least one photo first.");
                return;
            }
            scheduleDaily();
            updateStatus();
            toast("Daily wallpaper changes scheduled.");
        });
        LinearLayout.LayoutParams sp = matchWrap();
        sp.topMargin = dp(10);
        root.addView(start, sp);

        Button stop = button("Stop automatic changes");
        stop.setOnClickListener(v -> {
            cancelSchedule();
            updateStatus();
            toast("Automatic changes stopped.");
        });
        LinearLayout.LayoutParams stp = matchWrap();
        stp.topMargin = dp(10);
        root.addView(stop, stp);

        status = new TextView(this);
        status.setTextSize(15);
        status.setTextColor(0xFF263246);
        status.setPadding(0, dp(22), 0, dp(8));
        root.addView(status, matchWrap());

        TextView note = new TextView(this);
        note.setText("Notes: Android applies the same image to the home and lock screens when the system allows it. Daily changes use an inexact system alarm, so the exact time may vary. Some phones restrict background tasks; allow Auto Wallpaper to run if your phone offers that setting.");
        note.setTextSize(13);
        note.setTextColor(0xFF5C6574);
        note.setPadding(0, dp(12), 0, 0);
        root.addView(note, matchWrap());

        setContentView(root);
    }

    private void pickImages() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, PICK_IMAGES);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_IMAGES || resultCode != RESULT_OK || data == null) return;
        selected.clear();
        if (data.getClipData() != null) {
            for (int n = 0; n < data.getClipData().getItemCount(); n++) {
                Uri uri = data.getClipData().getItemAt(n).getUri();
                rememberUri(uri, data.getFlags());
            }
        } else if (data.getData() != null) {
            rememberUri(data.getData(), data.getFlags());
        }
        saveUris();
        updateStatus();
        toast(selected.size() + " photo(s) selected.");
    }

    private void rememberUri(Uri uri, int flags) {
        try {
            getContentResolver().takePersistableUriPermission(uri, flags & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION));
        } catch (Exception ignored) {}
        selected.add(uri.toString());
    }

    private void loadUris() {
        String raw = prefs.getString(KEY_URIS, "");
        selected.clear();
        if (!raw.isEmpty()) {
            for (String s : raw.split("\\n")) if (!s.trim().isEmpty()) selected.add(s.trim());
        }
    }

    private void saveUris() {
        StringBuilder b = new StringBuilder();
        for (String s : selected) {
            if (b.length() > 0) b.append('\n');
            b.append(s);
        }
        prefs.edit().putString(KEY_URIS, b.toString()).apply();
    }

    private void applyNext() {
        if (selected.isEmpty()) {
            toast("Choose at least one photo first.");
            return;
        }
        int index = prefs.getInt(KEY_NEXT, 0);
        String uriString = selected.get(index % selected.size());
        try (InputStream in = getContentResolver().openInputStream(Uri.parse(uriString))) {
            Bitmap bitmap = BitmapFactory.decodeStream(in);
            if (bitmap == null) throw new Exception("This image could not be opened.");
            WallpaperManager wm = WallpaperManager.getInstance(this);
            if (Build.VERSION.SDK_INT >= 24) {
                wm.setBitmap(bitmap, null, true, WallpaperManager.FLAG_SYSTEM | WallpaperManager.FLAG_LOCK);
            } else {
                wm.setBitmap(bitmap);
            }
            prefs.edit().putInt(KEY_NEXT, (index + 1) % selected.size()).apply();
            toast("Wallpaper changed.");
        } catch (Exception e) {
            toast("Couldn't apply this photo. Try selecting it again.");
        }
        updateStatus();
    }

    private void scheduleDaily() {
        Intent intent = new Intent(this, WallpaperAlarmReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(this, 42, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
        long first = System.currentTimeMillis() + 24L * 60L * 60L * 1000L;
        if (Build.VERSION.SDK_INT >= 23) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, first, pi);
        } else {
            am.set(AlarmManager.RTC_WAKEUP, first, pi);
        }
        prefs.edit().putBoolean("enabled", true).apply();
    }

    private void cancelSchedule() {
        Intent intent = new Intent(this, WallpaperAlarmReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(this, 42, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        ((AlarmManager) getSystemService(ALARM_SERVICE)).cancel(pi);
        pi.cancel();
        prefs.edit().putBoolean("enabled", false).apply();
    }

    private void updateStatus() {
        if (status == null) return;
        boolean enabled = prefs.getBoolean("enabled", false);
        status.setText("Selected photos: " + selected.size() + "\nAutomatic changes: " +
                (enabled ? "ON (every 24 hours)" : "OFF"));
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        return b;
    }
    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }
    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
