# Auto Wallpaper (Android)

A minimal native Android app that lets you select multiple images from your gallery and rotate the home + lock-screen wallpaper approximately every 24 hours.

## Features
- Select multiple gallery images with Android's document picker.
- Apply the next wallpaper immediately.
- Schedule daily rotation; stop it at any time.
- No internet permission and no ads.

## Build an APK
Requirements: Android Studio (Giraffe or newer recommended), Android SDK Platform 35, and JDK 17.

1. Open Android Studio.
2. Choose **Open** and select this `AutoWallpaper` folder.
3. Wait for Gradle sync.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show a link to the generated APK (usually `app/build/outputs/apk/debug/app-debug.apk`).
6. Transfer that APK to your Android phone and install it. You may need to allow installation from that source.

## Use
1. Open **Auto Wallpaper**.
2. Tap **Choose photos from gallery** and select multiple images.
3. Tap **Apply next wallpaper now** to test.
4. Tap **Start daily automatic changes**.
5. To stop, tap **Stop automatic changes**.

## Important Android behavior
- The app asks Android's system picker for image access; no broad gallery permission is needed.
- Exact scheduling is not guaranteed: Android can delay background alarms to save battery.
- Some manufacturers apply aggressive background restrictions. If daily changes do not run, check the phone's battery/background-app settings.
- Rebooting the phone clears this basic alarm schedule; open the app and press Start again after restarting.
- The app applies the same selected image to both home and lock screens on Android 7.0+. On older Android versions it applies the general wallpaper only.
